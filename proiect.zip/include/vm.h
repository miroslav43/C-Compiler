#pragma once

// Minimal VM header to satisfy ad.h dependency
typedef struct
{
    int opcode;
    // Add other fields as needed
} Instr;